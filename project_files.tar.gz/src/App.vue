<script setup>
import { ref, computed, onMounted } from 'vue';
import DashboardView from './views/DashboardView.vue';
import InputDataView from './views/InputDataView.vue';
import { useApi } from './composables/useApi';

const { transactions, fetchTransactions, addTransaction: apiAddTransaction } = useApi();

const selectedMonth = ref(new Date().getMonth() + 1);
const selectedYear = ref(new Date().getFullYear());
const filterDateType = ref('realizationDate');
const currentView = ref('dashboard'); // 'dashboard' or 'input'

onMounted(async () => {
  await fetchTransactions();
  if (transactions.value && transactions.value.length > 0) {
    const firstTransaction = transactions.value[0];
    const dateToUse = firstTransaction.realizationDate || firstTransaction.plannedDate;
    if (dateToUse) {
        const date = new Date(dateToUse);
        selectedMonth.value = date.getMonth() + 1;
        selectedYear.value = date.getFullYear();
    }
  }
});

const filteredTransactions = computed(() => {
  if (!transactions.value) return [];
  return transactions.value.filter(t => {
    const dateToFilter = t[filterDateType.value] || t.plannedDate;
    if (!dateToFilter) return false;
    const date = new Date(dateToFilter);
    return date.getMonth() + 1 === selectedMonth.value && date.getFullYear() === selectedYear.value;
  });
});

const addTransaction = async (transaction) => {
  await apiAddTransaction(transaction);
  currentView.value = 'dashboard'; // Switch to dashboard after adding a transaction
};

const updateMonth = (month) => {
  selectedMonth.value = month;
};

const updateYear = (year) => {
  selectedYear.value = year;
};

const updateFilterDateType = (type) => {
  filterDateType.value = type;
}

const setView = (view) => {
  currentView.value = view;
}

</script>

<template>
  <div id="app">
    <header>
      <h1>Cash Flow</h1>
      <nav>
        <button @click="setView('dashboard')" :class="{ active: currentView === 'dashboard' }">Dashboard</button>
        <button @click="setView('input')" :class="{ active: currentView === 'input' }">Input Data</button>
      </nav>
    </header>
    <main>
      <DashboardView v-if="currentView === 'dashboard'"
        :transactions="transactions"
        :filtered-transactions="filteredTransactions"
        :selected-month="selectedMonth"
        :selected-year="selectedYear"
        :filter-date-type="filterDateType"
        @update:month="updateMonth"
        @update:year="updateYear"
        @update:filterDateType="updateFilterDateType" />
      <InputDataView v-if="currentView === 'input'" @add-transaction="addTransaction" />
    </main>
  </div>
</template>

<style scoped>
#app {
  padding: 20px;
}
header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 40px;
}
header h1 {
  font-size: 2.5em;
  color: var(--primary-color);
}
nav {
  display: flex;
  gap: 10px;
}
nav button {
  background-color: transparent;
  color: var(--primary-color);
  border: 2px solid var(--primary-color);
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
}
nav button:hover, nav button.active {
  background-color: var(--primary-color);
  color: white;
}
</style>
