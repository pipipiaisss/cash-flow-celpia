<script setup>
import Dashboard from '../components/Dashboard.vue';
import CashFlowList from '../components/CashFlowList.vue';

defineProps({
  transactions: Array,
  filteredTransactions: Array,
  selectedMonth: Number,
  selectedYear: Number,
  filterDateType: String,
});

const emit = defineEmits(['update:month', 'update:year', 'update:filterDateType']);

const updateMonth = (month) => {
  emit('update:month', month);
};

const updateYear = (year) => {
  emit('update:year', year);
};

const updateFilterDateType = (type) => {
  emit('update:filterDateType', type);
}
</script>

<template>
  <div class="grid-container">
    <div class="card full-width-card">
      <Dashboard 
        :transactions="transactions" 
        :filtered-transactions="filteredTransactions"
        :selectedMonth="selectedMonth"
        :selectedYear="selectedYear"
        :filterDateType="filterDateType"
        @update:month="updateMonth"
        @update:year="updateYear"
        @update:filterDateType="updateFilterDateType"
      />
    </div>
    <div class="card full-width-card">
      <CashFlowList :transactions="filteredTransactions" />
    </div>
  </div>
</template>

<style scoped>
.grid-container {
  display: grid;
  grid-template-columns: 1fr;
  gap: 20px;
}
.full-width-card {
  width: 100%;
}
</style>
