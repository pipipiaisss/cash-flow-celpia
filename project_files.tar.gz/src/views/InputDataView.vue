<script setup>
import CashFlowForm from '../components/CashFlowForm.vue';

const emit = defineEmits(['add-transaction']);

const addTransaction = (transaction) => {
  emit('add-transaction', transaction);
};
</script>

<template>
  <div class="card">
    <CashFlowForm @add-transaction="addTransaction" />
  </div>
</template>

<style scoped>
.card {
  max-width: 800px;
  margin: 0 auto;
}
</style>
