<script setup>
import { ref } from 'vue';
import { useCurrencyFormatter } from '../composables/useCurrencyFormatter';

const emit = defineEmits(['add-transaction']);

const { 
  amount: plannedAmount, 
  formattedAmount: formattedPlannedAmount, 
  updateAmount: updatePlannedAmount 
} = useCurrencyFormatter();

const { 
  amount: realizationAmount, 
  formattedAmount: formattedRealizationAmount, 
  updateAmount: updateRealizationAmount 
} = useCurrencyFormatter();

const newTransaction = ref({
  plannedDate: '',
  realizationDate: '',
  name: '',
  type: 'cash-in',
  description: '',
  confirmed: false,
});

const addTransaction = () => {
  emit('add-transaction', { 
    ...newTransaction.value, 
    plannedAmount: plannedAmount.value,
    realizationAmount: realizationAmount.value,
  });
  // Reset fields
  newTransaction.value = {
    plannedDate: '',
    realizationDate: '',
    name: '',
    type: 'cash-in',
    description: '',
    confirmed: false,
  };
  plannedAmount.value = null;
  formattedPlannedAmount.value = '';
  realizationAmount.value = null;
  formattedRealizationAmount.value = '';
};
</script>

<template>
  <form @submit.prevent="addTransaction">
    <h3>Add New Transaction</h3>
    <div class="form-grid">
      <div class="form-group">
        <label>Name</label>
        <input type="text" v-model="newTransaction.name" placeholder="e.g., Salary" required />
      </div>
      <div class="form-group">
        <label>Type</label>
        <select v-model="newTransaction.type">
          <option value="cash-in">Cash In</option>
          <option value="cash-out">Cash Out</option>
        </select>
      </div>
      <div class="form-group">
        <label>Planned Amount</label>
        <input type="text" :value="formattedPlannedAmount" @input="updatePlannedAmount" placeholder="Rp 1.000.000" required />
      </div>
      <div class="form-group">
        <label>Planned Date</label>
        <input type="date" v-model="newTransaction.plannedDate" required />
      </div>
      <div class="form-group">
        <label>Realization Amount</label>
        <input type="text" :value="formattedRealizationAmount" @input="updateRealizationAmount" placeholder="Rp 1.000.000" />
      </div>
      <div class="form-group">
        <label>Realization Date</label>
        <input type="date" v-model="newTransaction.realizationDate" />
      </div>
      <div class="form-group full-width">
        <label>Description</label>
        <textarea v-model="newTransaction.description" placeholder="Monthly salary"></textarea>
      </div>
       <div class="form-group full-width">
        <label class="checkbox-label">
          <input type="checkbox" v-model="newTransaction.confirmed" />
          <span>Confirmed</span>
        </label>
      </div>
    </div>
    <button type="submit">Add Transaction</button>
  </form>
</template>

<style scoped>
form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}
.form-group {
  display: flex;
  flex-direction: column;
  gap: 5px;
}
.full-width {
  grid-column: 1 / -1;
}
label {
  font-weight: 500;
  color: #374151;
}
textarea {
  min-height: 80px;
  resize: vertical;
}
button {
  align-self: flex-end;
  width: auto;
  padding: 12px 20px;
}
.checkbox-label {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 10px;
  cursor: pointer;
}

.checkbox-label input[type="checkbox"] {
  width: auto;
}
</style>
