import { ref } from 'vue';

const API_URL = 'https://cash-flow-rouge.vercel.app/cashflows';

const frontendToBackendMapping = {
  type: 'type',
  name: 'nama_cash_flow',
  plannedDate: 'tanggal_perencanaan',
  realizationDate: 'tanggal_realisasi',
  plannedAmount: 'nominal_perencanaan',
  realizationAmount: 'nominal_realisasi',
  description: 'keterangan',
  confirmed: 'status',
};

const backendToFrontendMapping = {
  type: 'type',
  nama_cash_flow: 'name',
  tanggal_perencanaan: 'plannedDate',
  tanggal_realisasi: 'realizationDate',
  nominal_perencanaan: 'plannedAmount',
  nominal_realisasi: 'realizationAmount',
  keterangan: 'description',
  status: 'confirmed',
};

const transformToBackend = (data) => {
  const backendData = {};
  for (const key in data) {
    if (frontendToBackendMapping[key]) {
      let value = data[key];
      if (key === 'type') {
        value = value === 'cash-in' ? 'cashin' : 'cashout';
      } else if (key === 'confirmed') {
        value = value ? 'sudah dikonfirmasi' : 'belum dikonfirmasi';
      }
      // Pastikan tanggal kosong menjadi null
      if ((key === 'plannedDate' || key === 'realizationDate') && !value) {
        value = null;
      }

      backendData[frontendToBackendMapping[key]] = value;
    }
  }
  return backendData;
};

const transformToFrontend = (data) => {
  const frontendData = {};
  for (const key in data) {
    if (backendToFrontendMapping[key]) {
      let value = data[key];
      if (key === 'type') {
        value = value === 'cashin' ? 'cash-in' : 'cash-out';
      } else if (key === 'status') {
        value = value === 'sudah dikonfirmasi';
      }
      frontendData[backendToFrontendMapping[key]] = value;
    }
  }
  return frontendData;
};

export function useApi() {
  const transactions = ref([]);

  const fetchTransactions = async () => {
    try {
      const response = await fetch(API_URL);

      const contentType = response.headers.get("content-type");
      if (!response.ok || !contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        throw new Error(`Invalid response from server. Expected JSON, got ${contentType}. Response: ${text}`);
      }

      const data = await response.json();
      console.log('API Response:', data); // Log the raw API response
      transactions.value = data.map(transformToFrontend);
    } catch (error) {
      console.error('Error fetching transactions:', error);
      // Keep transactions empty on error
      transactions.value = [];
    }
  };

  const addTransaction = async (transaction) => {
    try {
      const backendTransaction = transformToBackend(transaction);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(backendTransaction),
      });

      if (!response.ok) {
          const text = await response.text();
          throw new Error(`HTTP error! status: ${response.status}, body: ${text}`);
      }

      const data = await response.json();
      console.log('Success:', data);
      await fetchTransactions(); // Refresh data
    } catch (error) {
      console.error('Error adding transaction:', error);
    }
  };

  return {
    transactions,
    fetchTransactions,
    addTransaction,
  };
}
