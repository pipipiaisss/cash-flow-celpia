
# Cash Flow Application

## Overview

A simple cash flow application to track cash-in and cash-out transactions. It allows users to input planned and actual financial data, and provides a dashboard with a monthly and yearly report.

## Features

*   **Backend Integration:** The application is fully integrated with a backend service to fetch and store transaction data.
*   **Navigation Menu:** A clear and simple menu to switch between the Dashboard and Data Input views.
*   **Dashboard View:**
    *   Displays the main dashboard with financial summaries.
    *   Shows a list of all transactions based on the selected filters, fetched from the backend.
*   **Data Input View:**
    *   Provides a form to add new cash-flow transactions, which are sent to the backend.
*   **Filtering:** Allows filtering transactions by month, year, and date type (Planned/Realization).
*   **Currency Formatting:** Input fields for amounts are automatically formatted as Indonesian Rupiah (IDR).
*   **Date Formatting:** Dates in the transaction list are displayed in `DD-MM-YYYY` format.

## Design

*   **Theme:** Professional, anime-inspired design.
*   **Layout:** A modern, responsive card-based layout with clean spacing and a visually balanced structure.
*   **Color Palette:** A vibrant and energetic color scheme with soft gradients and strong accent colors.
*   **Typography:** Using the "Poppins" font for a clean, modern, and readable text.
*   **Styling:** Custom-styled components including forms, buttons, and tables with subtle shadows and hover effects to create a premium feel.
*   **Interactivity:** Interactive elements have clear visual feedback with smooth transitions.

## Current Plan

*   Integrate the application with the backend API.
*   Create a `useApi` composable to handle all API communications.
*   Fetch transaction data from the backend when the application loads.
*   Send new transactions to the backend.
*   Refresh the transaction list after adding a new entry.
